package main

// baseline file just so we can compare the size

func main() {
	println("successfully did nothing")
}
